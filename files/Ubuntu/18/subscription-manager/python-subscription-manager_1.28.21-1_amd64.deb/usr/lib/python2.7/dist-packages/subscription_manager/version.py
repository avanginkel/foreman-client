from __future__ import print_function, division, absolute_import

# The values in this file are populated by setup.py build
rpm_version = ""
gtk_version = "2"
