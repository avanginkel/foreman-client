# -*- coding: utf-8 -*-

from __future__ import print_function, division, absolute_import

#
# Copyright (c) 2020 ATIX AG
#
# This software is licensed to you under the GNU General Public License,
# version 2 (GPLv2). There is NO WARRANTY for this software, express or
# implied, including the implied warranties of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. You should have received a copy of GPLv2
# along with this software; if not, see
# http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt.
#
# Red Hat trademarks are not licensed under GPLv2. No permission is
# granted to use or replicate Red Hat trademarks that are incorporated
# in this software or its documentation.
#
import logging
import subprocess

from rhsmlib.facts import collector
from rhsmlib.facts.hwprobe import HardwareCollector

log = logging.getLogger(__name__)


class SupportedArchesCollector(collector.FactsCollector):
    """
    Class used for collecting packages architectures of a host
    """

    def __init__(self, arch=None, prefix=None, testing=None):
        super(SupportedArchesCollector, self).__init__(
            arch=arch,
            prefix=prefix,
            testing=testing)

    def get_arches_on_debuntu(self):
        """
        Try to return content of all supported packages architectures
        :return: dictionary containing architectures
        Otherwise empty dictionary is returned.
        """
        arches = []

        try:
            output = str(subprocess.check_output("dpkg --print-architecture", shell=True))
            if output != '':
                arches.append(output.rstrip())
        except Exception as e:
            log.error("Error getting dpkg main architecture: %s", e)

        try:
            output = str(subprocess.check_output("dpkg --print-foreign-architectures", shell=True))
            if output != '':
                arches.append(output.rstrip())
        except Exception as e:
            log.error("Error getting dpkg foreign architecture: %s", e)

        return {
            'supported_architectures': ','.join(arches)
        }

    def get_all(self):
        """
        Get all architectures of a debian / ubuntu host
        :return: dictionary containing architectures
        """
        dist_name, version, dist_id, version_modifier = HardwareCollector().get_distribution()
        dist_name = dist_name.lower()
        if dist_name == 'ubuntu' or dist_name == 'debian':
            return self.get_arches_on_debuntu()
        return {}
